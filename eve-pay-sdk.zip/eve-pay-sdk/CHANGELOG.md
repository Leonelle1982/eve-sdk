# CHANGELOG
## v1.0.0 (Initial public release)
- Added SDK folder structure
- Included POST /payments/init & confirm examples
- OpenAPI contract added for ERP use cases
- Redmine integration guide added

